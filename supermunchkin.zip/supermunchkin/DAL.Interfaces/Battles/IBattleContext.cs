﻿namespace Interfaces.Battles
{
    public interface IBattleContext : IBattleRepository
    {
    }
}
