﻿namespace Interfaces.Games
{
    public interface IGameContext : IGameRepository, IGameCollectionRepository
    {
    }
}
