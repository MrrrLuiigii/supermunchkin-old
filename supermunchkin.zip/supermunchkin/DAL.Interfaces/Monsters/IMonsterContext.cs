﻿namespace Interfaces.Monsters
{
    public interface IMonsterContext : IMonsterRepository, IMonsterCollectionRepository
    {
    }
}
