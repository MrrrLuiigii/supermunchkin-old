﻿namespace Interfaces.Munchkins
{
    public interface IMunchkinContext : IMunchkinRepository
    {
    }
}
