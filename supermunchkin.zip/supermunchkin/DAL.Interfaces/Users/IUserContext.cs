﻿namespace Interfaces.Users
{
    public interface IUserContext : IUserRepository, IUserCollectionRepository
    {
    }
}
